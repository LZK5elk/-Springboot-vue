package com.lzk.redisdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//springboot启动类
@SpringBootApplication
//@SpringBootApplication 是springboot提供
//普通类加这个 这个类是启动类或 引导类
//启动类在项目启动时会自动创建spring 的ioc容器并扫描当前类的包和子包，使当前包和子包的所有注解生效
public class RedisdemoApplication {
    /**
     *
     * srpingboot 的入口 所有代码的开口
     * @param args
     */
    public static void main(String[] args) {
        /**
         * 启动sprigboot程序 调用application
         */
        SpringApplication.run(RedisdemoApplication.class, args);
    }

}
