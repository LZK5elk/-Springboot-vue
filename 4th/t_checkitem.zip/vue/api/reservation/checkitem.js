import request from '@/utils/request'

// 查询检查项管理列表
export function listCheckitem(query) {
  return request({
    url: '/reservation/checkitem/list',
    method: 'get',
    params: query
  })
}

// 查询检查项管理详细
export function getCheckitem(id) {
  return request({
    url: '/reservation/checkitem/' + id,
    method: 'get'
  })
}

// 新增检查项管理
export function addCheckitem(data) {
  return request({
    url: '/reservation/checkitem',
    method: 'post',
    data: data
  })
}

// 修改检查项管理
export function updateCheckitem(data) {
  return request({
    url: '/reservation/checkitem',
    method: 'put',
    data: data
  })
}

// 删除检查项管理
export function delCheckitem(id) {
  return request({
    url: '/reservation/checkitem/' + id,
    method: 'delete'
  })
}
