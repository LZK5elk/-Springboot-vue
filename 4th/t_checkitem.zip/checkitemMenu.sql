-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('检查项管理', '2000', '1', 'checkitem', 'reservation/checkitem/index', 1, 0, 'C', '0', '0', 'reservation:checkitem:list', '#', 'admin', sysdate(), '', null, '检查项管理菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('检查项管理查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'reservation:checkitem:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('检查项管理新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'reservation:checkitem:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('检查项管理修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'reservation:checkitem:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('检查项管理删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'reservation:checkitem:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('检查项管理导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'reservation:checkitem:export',       '#', 'admin', sysdate(), '', null, '');